mvskoke languistics library
========================
